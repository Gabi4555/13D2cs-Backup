using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace autoform
{
    public partial class Form1 : Form
    {
        private List<Auto> autok = new List<Auto>();

        public Form1()
        {
            InitializeComponent();
            this.Text = "Aut�k";
            dataGridView1.ReadOnly = true;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnBetolt_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "CSV f�jlok|*.csv";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    autok = Auto.BetoltFajlbol(ofd.FileName);
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = autok;
                    listBoxEredmeny.Items.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hiba t�rt�nt a f�jl bet�lt�sekor:\n" + ex.Message, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnSzures_Click(object sender, EventArgs e)
        {
            listBoxEredmeny.Items.Clear();

            if (int.TryParse(txtEv.Text, out int keresettEv))
            {
                var eredmenyek = autok
                    .Where(a => a.Evjarat == keresettEv)
                    .Select(a => $"{a.Marka} {a.Modell}")
                    .ToList();

                if (eredmenyek.Count > 0)
                {
                    foreach (var auto in eredmenyek)
                    {
                        listBoxEredmeny.Items.Add(auto);
                    }
                }
                else
                {
                    MessageBox.Show("Nem tal�lhat� aut� a megadott �vben.", "Nincs tal�lat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("K�rlek adj meg egy �rv�nyes �vsz�mot!", "Hib�s adat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnKilep_Click(object sender, EventArgs e)
        {
            var valasz = MessageBox.Show("Biztosan ki szeretne l�pni?", "Kil�p�s meger�s�t�se", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (valasz == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
